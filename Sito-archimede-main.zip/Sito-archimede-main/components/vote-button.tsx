"use client"

import { useState, useEffect } from "react"
import { ThumbsUp, ThumbsDown } from "lucide-react"
import { Button } from "@/components/ui/button"
import { createClient } from "@/lib/supabase/client"

interface VoteButtonProps {
  itemId: string
  itemType: "news" | "proposal" | "service"
}

function getUserSession(): string {
  if (typeof window === "undefined") return ""

  let sessionId = localStorage.getItem("vote_session_id")
  if (!sessionId) {
    sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
    localStorage.setItem("vote_session_id", sessionId)
  }
  return sessionId
}

export function VoteButton({ itemId, itemType }: VoteButtonProps) {
  const [proCounts, setProCounts] = useState(0)
  const [controCounts, setControCounts] = useState(0)
  const [isVoting, setIsVoting] = useState(false)
  const [proAnimating, setProAnimating] = useState(false)
  const [controAnimating, setControAnimating] = useState(false)
  const [countChanged, setCountChanged] = useState<"pro" | "contro" | null>(null)
  const [userVote, setUserVote] = useState<"pro" | "contro" | null>(null)
  const supabase = createClient()

  // Fetch initial vote counts
  useEffect(() => {
    fetchVoteCounts()
    checkUserVote()

    // Subscribe to real-time updates
    const channel = supabase
      .channel(`votes-${itemId}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "votes",
          filter: `item_id=eq.${itemId}`,
        },
        () => {
          fetchVoteCounts()
          checkUserVote()
        },
      )
      .subscribe()

    return () => {
      supabase.removeChannel(channel)
    }
  }, [itemId])

  const checkUserVote = async () => {
    const sessionId = getUserSession()
    const { data } = await supabase
      .from("votes")
      .select("vote_type")
      .eq("item_id", itemId)
      .eq("item_type", itemType)
      .eq("user_session", sessionId)
      .single()

    if (data) {
      setUserVote(data.vote_type as "pro" | "contro")
    } else {
      setUserVote(null)
    }
  }

  const fetchVoteCounts = async () => {
    const { data, error } = await supabase
      .from("vote_counts")
      .select("pro_count, contro_count")
      .eq("item_id", itemId)
      .eq("item_type", itemType)
      .single()

    if (!error && data) {
      const pro = data.pro_count || 0
      const contro = data.contro_count || 0

      if (pro !== proCounts) {
        setCountChanged("pro")
        setTimeout(() => setCountChanged(null), 600)
      }
      if (contro !== controCounts) {
        setCountChanged("contro")
        setTimeout(() => setCountChanged(null), 600)
      }

      setProCounts(pro)
      setControCounts(contro)
    } else if (error && error.code === "PGRST116") {
      // Nessun voto ancora per questo item
      setProCounts(0)
      setControCounts(0)
    }
  }

  const handleVote = async (voteType: "pro" | "contro") => {
    setIsVoting(true)
    if (voteType === "pro") {
      setProAnimating(true)
      setTimeout(() => setProAnimating(false), 300)
    } else {
      setControAnimating(true)
      setTimeout(() => setControAnimating(false), 300)
    }

    try {
      const sessionId = getUserSession()
      const previousVote = userVote

      if (previousVote === voteType) {
        // Se clicca sullo stesso voto, non fa nulla (già votato)
        setIsVoting(false)
        return
      }

      if (previousVote) {
        // Rimuovi il voto precedente dai conteggi locali
        if (previousVote === "pro") {
          setProCounts((prev) => Math.max(0, prev - 1))
        } else {
          setControCounts((prev) => Math.max(0, prev - 1))
        }
      }

      // Aggiungi il nuovo voto ai conteggi locali
      if (voteType === "pro") {
        setProCounts((prev) => prev + 1)
        setCountChanged("pro")
      } else {
        setControCounts((prev) => prev + 1)
        setCountChanged("contro")
      }
      setTimeout(() => setCountChanged(null), 600)

      // Aggiorna lo stato del voto utente immediatamente
      setUserVote(voteType)

      // If user already voted, delete the old vote first
      if (previousVote) {
        await supabase
          .from("votes")
          .delete()
          .eq("item_id", itemId)
          .eq("item_type", itemType)
          .eq("user_session", sessionId)
      }

      // Insert new vote
      const { error } = await supabase.from("votes").insert({
        item_id: itemId,
        item_type: itemType,
        vote_type: voteType,
        user_session: sessionId,
      })

      if (error) {
        console.error("Error voting:", error)
        // Ripristina i conteggi in caso di errore
        if (previousVote) {
          if (previousVote === "pro") {
            setProCounts((prev) => prev + 1)
          } else {
            setControCounts((prev) => prev + 1)
          }
        }
        if (voteType === "pro") {
          setProCounts((prev) => Math.max(0, prev - 1))
        } else {
          setControCounts((prev) => Math.max(0, prev - 1))
        }
        setUserVote(previousVote)
      }
    } catch (error) {
      console.error("Error voting:", error)
    } finally {
      setIsVoting(false)
    }
  }

  return (
    <div className="flex items-center gap-3">
      <Button
        variant="outline"
        size="sm"
        onClick={() => handleVote("pro")}
        disabled={isVoting}
        className={`gap-2 hover:bg-primary/10 hover:text-primary transition-all duration-200 ${
          proAnimating ? "scale-110 bg-primary/20" : ""
        } ${userVote === "pro" ? "bg-primary/20 border-primary text-primary" : ""}`}
      >
        <ThumbsUp className={`h-4 w-4 transition-transform ${proAnimating ? "scale-125" : ""}`} />
        <span
          className={`font-semibold transition-all duration-300 ${
            countChanged === "pro" ? "scale-125 text-primary" : ""
          }`}
        >
          {proCounts}
        </span>
      </Button>
      <Button
        variant="outline"
        size="sm"
        onClick={() => handleVote("contro")}
        disabled={isVoting}
        className={`gap-2 hover:bg-destructive/10 hover:text-destructive transition-all duration-200 ${
          controAnimating ? "scale-110 bg-destructive/20" : ""
        } ${userVote === "contro" ? "bg-destructive/20 border-destructive text-destructive" : ""}`}
      >
        <ThumbsDown className={`h-4 w-4 transition-transform ${controAnimating ? "scale-125" : ""}`} />
        <span
          className={`font-semibold transition-all duration-300 ${
            countChanged === "contro" ? "scale-125 text-destructive" : ""
          }`}
        >
          {controCounts}
        </span>
      </Button>
    </div>
  )
}
