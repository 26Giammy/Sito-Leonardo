import { GraduationCap } from "lucide-react"
import { MobileSidebar } from "./mobile-sidebar"

export function Header() {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto flex h-16 max-w-screen-xl items-center justify-between px-4">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-20 items-center justify-center rounded-lg bg-gradient-to-br from-primary to-accent animate-float">
            <p className="font-mono text-center text-background font-bold opacity-85 shadow-md tracking-wider border-0">UTOPIA</p>       
          </div>
          <div>
            <h1 className="text-lg font-bold text-foreground">{"Liceo Archimede"}</h1>
            <p className="text-xs text-muted-foreground">Portale Studenti</p>
          </div>
        </div>

        <nav className="hidden md:flex items-center gap-6">
          <a
            href="#home"
            className="text-sm font-medium text-foreground hover:text-primary transition-all duration-200 hover:scale-105"
          >
            Home
          </a>
          <a
            href="#news"
            className="text-sm font-medium text-foreground hover:text-primary transition-all duration-200 hover:scale-105"
          >
            Notizie
          </a>
          <a
            href="#servizi"
            className="text-sm font-medium text-foreground hover:text-primary transition-all duration-200 hover:scale-105"
          >
            Servizi
          </a>
          <a
            href="#contatti"
            className="text-sm font-medium text-foreground hover:text-primary transition-all duration-200 hover:scale-105"
          >
            Contatti
          </a>
        </nav>

        <MobileSidebar />
      </div>
    </header>
  )
}
