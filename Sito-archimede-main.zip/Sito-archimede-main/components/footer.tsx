import { GraduationCap, Mail, MessageCircle, Instagram, Heart } from "lucide-react"

export function Footer() {
  return (
    <footer id="contatti" className="border-t border-border/40 bg-gradient-to-b from-muted/30 to-muted/50">
      <div className="container mx-auto max-w-screen-xl px-4 py-12">
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
          {/* Brand */}
          <div className="space-y-4 animate-fade-in">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-accent animate-float">
                <GraduationCap className="h-6 w-6 text-primary-foreground" />
              </div>
              <span className="font-bold text-foreground">{"Portale Studenti"}</span>
            </div>
            <p className="text-sm text-muted-foreground text-pretty">
              Rappresentiamo gli studenti e lavoriamo per migliorare la vita scolastica di tutti.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4 animate-fade-in [animation-delay:0.1s]">
            <h3 className="font-semibold text-foreground">Link rapidi</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <a
                  href="#home"
                  className="text-muted-foreground hover:text-primary transition-all duration-200 hover:translate-x-1"
                >
                  Home
                </a>
              </li>
              <li>
                <a
                  href="#news"
                  className="text-muted-foreground hover:text-primary transition-all duration-200 hover:translate-x-1"
                >
                  Notizie
                </a>
              </li>
              <li>
                <a
                  href="#servizi"
                  className="text-muted-foreground hover:text-primary transition-all duration-200 hover:translate-x-1"
                >
                  I nostri servizi
                </a>
              </li>
              <li>
                <a
                  href="#contatti"
                  className="text-muted-foreground hover:text-primary transition-all duration-200 hover:translate-x-1"
                >
                  Contatti
                </a>
              </li>
            </ul>
          </div>

          {/* Services */}
          <div className="space-y-4 animate-fade-in [animation-delay:0.2s]">
            <h3 className="font-semibold text-foreground">Servizi</h3>
            <ul className="space-y-2 text-sm">
              <li className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">
                Domande e risposte
              </li>
              <li className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">Interviste</li>
              <li className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">
                Segnalazioni anonime
              </li>
              <li className="text-muted-foreground hover:text-primary transition-colors cursor-pointer">
                Proposte e idee
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div className="space-y-4 animate-fade-in [animation-delay:0.3s]">
            <h3 className="font-semibold text-foreground">Contatti</h3>
            <div className="space-y-3">
              <a
                href="mailto:info@listaxyz.scuola.it"
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-all duration-200 hover:translate-x-1 group"
              >
                <Mail className="h-4 w-4 group-hover:scale-110 transition-transform" />
                info@utopia.scuola.it
              </a>
              <a
                href="https://www.instagram.com/utopia.archimede?igsh=MWZyYmhqam44ZnNmOA%3D%3D&utm_source=qr"
                className="flex items-center gap-2 text-sm text-muted-foreground hover:text-primary transition-all duration-200 hover:translate-x-1 group"
              >
                <Instagram className="h-4 w-4 group-hover:scale-110 transition-transform" />
                Instagram
              </a>
            </div>
          </div>
        </div>

        <div className="mt-8 border-t border-border/40 pt-8 text-center animate-fade-in [animation-delay:0.4s]">
          <p className="text-sm text-muted-foreground">
            © 2025 Portale Studenti by Utopia.
                  <br/> Built by</p> 
            <a className="font-sans font-light text-secondary-foreground py-0 my-0" href="https://www.instagram.com/_gianmarco.marino?igsh=OHJ3MHFxMmZ0cWNr&utm_source=qr">Gianmarco Marino</a>
          
        </div>
      </div>
    </footer>
  )
}
