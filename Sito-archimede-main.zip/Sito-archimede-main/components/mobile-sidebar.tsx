"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Menu, Home, MessageSquare, Users, AlertTriangle, Lightbulb, Newspaper } from "lucide-react"

const navigationItems = [
  { href: "#home", label: "Home", icon: Home },
  { href: "#news", label: "Notizie", icon: Newspaper },
  { href: "#domande", label: "Fai una domanda", icon: MessageSquare },
  { href: "#interviste", label: "Partecipa a un'intervista", icon: Users },
  { href: "#segnalazioni", label: "Segnala un problema", icon: AlertTriangle },
  { href: "#idee", label: "Proponi un'idea", icon: Lightbulb },
]

export function MobileSidebar() {
  const [open, setOpen] = useState(false)

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:hidden">
          <Menu className="h-5 w-5" />
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-80 p-0">
        <div className="flex h-full flex-col bg-gradient-to-b from-primary/5 to-accent/5">
          <div className="p-6 border-b border-border/50">
            <h2 className="text-lg font-semibold text-foreground">Navigazione</h2>
            <p className="text-sm text-muted-foreground">Portale Studenti</p>
          </div>
          <nav className="flex-1 p-4 space-y-2">
            {navigationItems.map((item) => {
              const Icon = item.icon
              return (
                <a
                  key={item.href}
                  href={item.href}
                  onClick={() => setOpen(false)}
                  className="flex items-center gap-3 px-4 py-3 rounded-lg text-sm font-medium text-foreground hover:bg-primary/10 hover:text-primary transition-all duration-200 group"
                >
                  <Icon className="h-5 w-5 group-hover:scale-110 transition-transform duration-200" />
                  {item.label}
                </a>
              )
            })}
          </nav>
        </div>
      </SheetContent>
    </Sheet>
  )
}
