import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Clock, TrendingUp, Users } from "lucide-react"
import { VoteButton } from "@/components/vote-button"

export function NewsSection() {
  return (
    <section
      id="news"
      className="py-16 px-4 bg-gradient-to-br from-primary/5 via-background to-accent/5 relative overflow-hidden"
    >
      <div className="container mx-auto max-w-4xl">
        <div className="text-center mb-12 animate-fade-in">
          <Badge variant="secondary" className="mb-4 px-4 py-2 animate-bounce-subtle hover:animate-pulse-glow">
            <Calendar className="h-4 w-4 mr-2 animate-rotate-slow" />
            Aggiornamenti Settimanali
          </Badge>
          <h2 className="text-3xl font-bold text-foreground mb-4 animate-text-shimmer bg-gradient-to-r from-foreground via-primary to-accent bg-clip-text text-transparent bg-[length:200%_auto]">
            Notizie e Aggiornamenti
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto italic shadow-xs font-semibold animate-slide-up [animation-delay:0.2s]">
            Resta aggiornato sulle ultime novità
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 animate-slide-up [animation-delay:0.3s]">
          {/* Featured News Card */}
          <Card className="md:col-span-2 overflow-hidden group hover-lift animate-scale-in [animation-delay:0.4s]">
            <div className="relative">
              <div className="aspect-video bg-gradient-to-br from-primary/20 via-accent/10 to-primary/20 flex items-center justify-center animate-gradient-shift bg-[length:200%_auto]">
                <div className="text-center p-8">
                  <div className="w-16 h-16 bg-primary/20 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse-glow">
                    <Calendar className="h-8 w-8 text-primary animate-bounce-subtle" />
                  </div>
                  <p className="text-muted-foreground">Qui verrà inserito il video/foto della settimana</p>
                </div>
              </div>
              <Badge className="absolute top-4 left-4 bg-primary text-primary-foreground animate-bounce-subtle">
                In Evidenza
              </Badge>
            </div>
            <CardContent className="p-6">
              <div className="flex items-center gap-2 text-sm text-muted-foreground mb-3">
                <Clock className="h-4 w-4 animate-rotate-slow" />
                <span>Pubblicato questa settimana</span>
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3 group-hover:text-primary transition-colors duration-300">
                Novità della Settimana
              </h3>
              <p className="text-muted-foreground leading-relaxed mb-4">
                Qui verrà inserito il paragrafo con le notizie settimanali più importanti. Questo spazio sarà aggiornato
                regolarmente con informazioni su eventi, iniziative e aggiornamenti della lista studentesca.
              </p>
              <div className="flex items-center justify-between pt-4 border-t">
                <span className="text-sm text-muted-foreground">Cosa ne pensi?</span>
                <VoteButton itemId="featured-news-weekly" itemType="news" />
              </div>
            </CardContent>
          </Card>

          <Card className="group hover-lift animate-slide-in-left [animation-delay:0.6s]">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-3">
                <TrendingUp className="h-5 w-5 text-primary animate-bounce-subtle" />
                <h4 className="font-semibold text-foreground">Prossimi Eventi</h4>
              </div>
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50 hover:bg-muted/70 transition-all duration-200 hover:scale-105">
                  <div className="w-2 h-2 bg-primary rounded-full animate-pulse-glow"></div>
                  <div>
                    <p className="text-sm font-medium">Assemblea Studentesca</p>
                    <p className="text-xs text-muted-foreground">Data da definire</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50 hover:bg-muted/70 transition-all duration-200 hover:scale-105">
                  <div className="w-2 h-2 bg-accent rounded-full animate-pulse-glow [animation-delay:0.5s]"></div>
                  <div>
                    <p className="text-sm font-medium">Raccolta Proposte</p>
                    <p className="text-xs text-muted-foreground">In corso</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="group hover-lift animate-slide-in-right [animation-delay:0.8s]">
            <CardContent className="p-6">
              <div className="flex items-center gap-2 mb-3">
                <Users className="h-5 w-5 text-accent animate-bounce-subtle [animation-delay:0.3s]" />
                <h4 className="font-semibold text-foreground">Statistiche</h4>
              </div>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Domande Ricevute</span>
                    <span className="font-medium text-primary">42</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2 overflow-hidden">
                    <div className="bg-gradient-to-r from-primary to-accent h-2 rounded-full w-3/4 animate-gradient-shift bg-[length:200%_auto]"></div>
                  </div>
                </div>
                <div>
                  <div className="flex justify-between text-sm mb-1">
                    <span>Segnalazioni Risolte</span>
                    <span className="font-medium text-accent">18</span>
                  </div>
                  <div className="w-full bg-muted rounded-full h-2 overflow-hidden">
                    <div className="bg-gradient-to-r from-accent to-primary h-2 rounded-full w-1/2 animate-gradient-shift bg-[length:200%_auto] [animation-delay:1s]"></div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <div className="absolute inset-0 -z-10 overflow-hidden pointer-events-none">
        <div className="absolute top-10 right-10 h-32 w-32 rounded-full bg-gradient-to-br from-primary/15 to-accent/10 blur-2xl animate-float [animation-delay:2s]"></div>
        <div className="absolute bottom-10 left-10 h-40 w-40 rounded-full bg-gradient-to-br from-accent/15 to-primary/10 blur-2xl animate-float [animation-delay:4s]"></div>
      </div>
    </section>
  )
}
