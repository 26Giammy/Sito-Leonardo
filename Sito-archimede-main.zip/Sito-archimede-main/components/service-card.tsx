import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { type LucideIcon, ExternalLink, Sparkles } from "lucide-react"

interface ServiceCardProps {
  icon: LucideIcon
  title: string
  description: string
  buttonText: string
  href: string
  id: string
}

export function ServiceCard({ icon: Icon, title, description, buttonText, href, id }: ServiceCardProps) {
  return (
    <Card className="group relative overflow-hidden border-0 bg-gradient-to-br from-card/80 via-card/60 to-card/40 backdrop-blur-xl transition-all duration-700 hover:shadow-2xl hover:shadow-primary/20 hover:-translate-y-3 hover:scale-[1.02] animate-float">
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5 opacity-0 group-hover:opacity-100 transition-all duration-700" />

      <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/10 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-1000 ease-out" />

      <div className="absolute inset-0 rounded-lg bg-gradient-to-r from-primary/30 via-accent/30 to-primary/30 opacity-0 group-hover:opacity-100 transition-all duration-500 blur-sm animate-pulse-glow" />
      <div className="absolute inset-[1px] rounded-lg bg-card/90 backdrop-blur-sm" />

      <div className="relative z-10">
        <CardHeader className="space-y-6 pb-4">
          <div className="relative">
            <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-primary/20 via-primary/10 to-accent/20 text-primary group-hover:from-primary/40 group-hover:via-primary/20 group-hover:to-accent/40 transition-all duration-500 group-hover:scale-110 group-hover:rotate-6 shadow-lg group-hover:shadow-primary/20">
              <Icon className="h-8 w-8 transition-all duration-300 group-hover:scale-110" />
            </div>
            <Sparkles className="absolute -top-1 -right-1 h-4 w-4 text-accent opacity-0 group-hover:opacity-100 transition-all duration-300 animate-spin-slow" />
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-primary/20 to-accent/20 blur-md opacity-0 group-hover:opacity-50 transition-all duration-500 animate-pulse-glow" />
          </div>

          <CardTitle className="text-xl font-bold text-balance group-hover:text-primary transition-all duration-300 group-hover:scale-105 bg-gradient-to-r from-foreground to-foreground/80 group-hover:from-primary group-hover:to-accent bg-clip-text group-hover:text-transparent">
            {title}
          </CardTitle>
        </CardHeader>

        <CardContent className="pb-6">
          <CardDescription className="text-base leading-relaxed text-pretty group-hover:text-foreground/90 transition-colors duration-300">
            {description}
          </CardDescription>
        </CardContent>

        <CardFooter className="pt-2">
          <Button
            className="w-full group/button relative overflow-hidden bg-gradient-to-r from-primary via-primary/90 to-accent hover:from-primary/90 hover:via-accent/90 hover:to-primary transition-all duration-500 hover:scale-105 hover:shadow-lg hover:shadow-primary/30 border-0 text-primary-foreground font-semibold"
            asChild
            disabled={href === "#"}
          >
            <a href={href} target="_blank" rel="noopener noreferrer" className="relative z-10">
              <span className="relative z-10 flex items-center justify-center">
                {buttonText}
                <ExternalLink className="ml-2 h-4 w-4 transition-all duration-300 group-hover/button:translate-x-1 group-hover/button:-translate-y-1 group-hover/button:scale-110" />
              </span>
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover/button:translate-x-full transition-transform duration-700 ease-out" />
            </a>
          </Button>
        </CardFooter>
      </div>

      <div className="absolute inset-0 rounded-lg bg-gradient-to-br from-primary/10 via-accent/5 to-primary/10 opacity-0 group-hover:opacity-100 transition-all duration-700 -z-10 blur-2xl scale-110" />

      <div className="absolute top-4 right-4 w-20 h-20 bg-gradient-to-br from-primary/10 to-accent/10 rounded-full opacity-0 group-hover:opacity-30 transition-all duration-500 blur-xl animate-pulse-glow" />
      <div className="absolute bottom-4 left-4 w-16 h-16 bg-gradient-to-tl from-accent/10 to-primary/10 rounded-full opacity-0 group-hover:opacity-20 transition-all duration-700 blur-lg animate-float" />
    </Card>
  )
}
