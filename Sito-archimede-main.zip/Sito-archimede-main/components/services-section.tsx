import type React from "react"
import { ServiceCard } from "@/components/service-card"
import { MessageCircleQuestion, Users, AlertTriangle, Lightbulb } from "lucide-react"
import { Badge } from "@/components/ui/badge"

const services = [
  {
    icon: MessageCircleQuestion,
    title: "Fai una domanda",
    description:
      "Hai dubbi su regolamenti, procedure o attività scolastiche? Invia la tua domanda e riceverai una risposta chiara e tempestiva dal nostro team.",
    buttonText: "Invia domanda",
    href: "https://forms.gle/uxDmQy8srvJpTDDV9", // Placeholder per Google Form
    id: "domande",
  },
  {
    icon: Users,
    title: "Partecipa a un'intervista",
    description:
      "Vuoi condividere la tua esperienza o dare il tuo contributo su temi importanti? Candidati per partecipare alle nostre interviste e fai sentire la tua voce.",
    buttonText: "Candidati",
    href: "https://forms.gle/U92rKJMicHJqguhH8", // Placeholder per Google Form
    id: "interviste",
  },
  {
    icon: AlertTriangle,
    title: "Segnala un problema",
    description:
      "Hai notato qualcosa che non va nella scuola? Le segnalazioni anonime ci aiutano a identificare e risolvere i problemi per migliorare l'ambiente scolastico.",
    buttonText: "Segnala anonimamente",
    href: "https://forms.gle/PzNE1BFg377DH7MW8", // Placeholder per Google Form
    id: "segnalazioni",
  },
  {
    icon: Lightbulb,
    title: "Proponi un'idea",
    description:
      "Hai un'idea brillante per migliorare la scuola? Condividi le tue proposte innovative e aiutaci a costruire insieme un futuro migliore per tutti gli studenti.",
    buttonText: "Condividi idea",
    href: "https://forms.gle/zo27oncbPEYYKadZ8", // Placeholder per Google Form
    id: "idee",
  },
]

export function ServicesSection() {
  return (
    <section id="servizi" className="py-24 bg-gradient-to-b from-background to-muted/20 relative overflow-hidden">
      <div className="container mx-auto max-w-screen-xl px-4">
        <div className="text-center space-y-4 mb-16 animate-fade-in">
          <Badge variant="secondary" className="mb-4 px-4 py-2 animate-bounce-subtle hover:animate-pulse-glow">
            I nostri servizi
          </Badge>
          <h2 className="text-3xl font-bold tracking-tight text-balance sm:text-4xl bg-gradient-to-r from-foreground via-primary to-accent bg-clip-text text-transparent animate-text-shimmer bg-[length:200%_auto]">
            Quattro modi per partecipare
          </h2>
          <p className="mx-auto max-w-2xl text-lg text-muted-foreground text-pretty animate-slide-up [animation-delay:0.2s]">
            Scegli il modo che preferisci per far sentire la tua voce e contribuire al miglioramento della nostra scuola
          </p>
        </div>

        <div className="grid gap-8 md:grid-cols-2 lg:gap-12">
          {services.map((service, index) => (
            <div
              key={index}
              id={service.id}
              className="animate-slide-up hover-lift"
              style={
                {
                  animationDelay: `${index * 0.15}s`,
                  "--stagger": index,
                } as React.CSSProperties
              }
            >
              <ServiceCard {...service} />
            </div>
          ))}
        </div>
      </div>

      <div className="absolute inset-0 -z-10 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 -left-20 h-64 w-64 rounded-full bg-gradient-to-br from-primary/10 to-accent/5 blur-3xl animate-float [animation-delay:1s]"></div>
        <div className="absolute bottom-1/4 -right-20 h-64 w-64 rounded-full bg-gradient-to-br from-accent/10 to-primary/5 blur-3xl animate-float [animation-delay:3s]"></div>
      </div>
    </section>
  )
}
