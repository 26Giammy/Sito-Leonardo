import { Button } from "@/components/ui/button"
import { ArrowDown, Sparkles } from "lucide-react"

export function HeroSection() {
  return (
    <section
      id="home"
      className="relative min-h-[80vh] flex items-center justify-center bg-gradient-to-br from-background via-primary/5 to-accent/10 overflow-hidden"
    >
      <div className="container mx-auto max-w-screen-xl px-4 text-center">
        <div className="mx-auto max-w-3xl space-y-8 animate-fade-in">
          <div className="space-y-4">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary text-sm font-medium mb-6 animate-scale-in animate-pulse-glow hover:animate-bounce-subtle">
              <Sparkles className="h-4 w-4 animate-rotate-slow" />
              By Utopia
            </div>
            <h1 className="text-4xl font-bold tracking-tight text-balance sm:text-5xl md:text-6xl bg-gradient-to-r from-foreground via-primary to-accent bg-clip-text text-transparent animate-slide-up animate-text-shimmer bg-[length:200%_auto]">
              La tua voce conta
            </h1>
            <p className="mx-auto max-w-2xl text-lg text-muted-foreground text-pretty sm:text-xl animate-slide-in-left [animation-delay:0.2s]">
              Benvenuto nel portale ufficiale della{" "}
              <strong className="text-primary animate-text-shimmer bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent bg-[length:200%_auto]">
                {"Liceo Archimede"}
              </strong>
              . Qui puoi fare domande, partecipare a interviste, segnalare problemi e proporre idee per migliorare la
              nostra scuola insieme.
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-in-right [animation-delay:0.4s]">
            <Button
              size="lg"
              className="text-base group hover-lift animate-gradient-shift bg-gradient-to-r from-primary via-accent to-primary bg-[length:200%_auto]"
              asChild
            >
              <a href="#news">
                Scopri le novità
                <ArrowDown className="ml-2 h-4 w-4 group-hover:translate-y-1 group-hover:animate-bounce-subtle transition-transform" />
              </a>
            </Button>
            <Button
              variant="outline"
              size="lg"
              className="text-base bg-transparent hover:bg-primary/5 hover-lift border-primary/20 hover:border-primary/40"
              asChild
            >
              <a href="#servizi">Esplora servizi</a>
            </Button>
          </div>
        </div>
      </div>

      <div className="absolute inset-0 -z-10 overflow-hidden">
        <div className="absolute -top-40 -right-32 h-80 w-80 rounded-full bg-gradient-to-br from-primary/20 to-accent/10 blur-3xl animate-float animate-pulse-glow"></div>
        <div className="absolute -bottom-40 -left-32 h-80 w-80 rounded-full bg-gradient-to-br from-accent/20 to-primary/10 blur-3xl animate-float animate-pulse-glow [animation-delay:1s]"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-96 w-96 rounded-full bg-gradient-to-br from-primary/5 to-accent/5 blur-3xl animate-float animate-rotate-slow [animation-delay:2s]"></div>
        <div className="absolute top-20 right-20 h-32 w-32 rounded-full bg-gradient-to-br from-accent/30 to-primary/20 blur-2xl animate-bounce-subtle [animation-delay:3s]"></div>
        <div className="absolute bottom-20 left-20 h-40 w-40 rounded-full bg-gradient-to-br from-primary/25 to-accent/15 blur-2xl animate-float [animation-delay:4s]"></div>
      </div>
    </section>
  )
}
