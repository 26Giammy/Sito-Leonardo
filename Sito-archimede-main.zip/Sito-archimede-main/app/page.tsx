"use client"

import { useEffect } from "react"
import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { NewsSection } from "@/components/news-section"
import { ServicesSection } from "@/components/services-section"
import { Footer } from "@/components/footer"

export default function HomePage() {
  useEffect(() => {
    // Scroll immediato all'inizio della pagina
    window.scrollTo({ top: 0, left: 0, behavior: "instant" })

    // Previene scroll automatici indesiderati per i primi 2 secondi
    const preventScroll = (e: Event) => {
      e.preventDefault()
      window.scrollTo({ top: 0, left: 0, behavior: "instant" })
    }

    // Aggiunge listener per prevenire scroll automatici
    window.addEventListener("scroll", preventScroll, { passive: false })

    // Rimuove il listener dopo 2 secondi per permettere scroll manuale
    const timer = setTimeout(() => {
      window.removeEventListener("scroll", preventScroll)
    }, 500)

    return () => {
      clearTimeout(timer)
      window.removeEventListener("scroll", preventScroll)
    }
  }, [])

  return (
    <main className="min-h-screen bg-background">
      <Header />
      <HeroSection />
      <NewsSection />
      <ServicesSection />
      <Footer />
    </main>
  )
}
