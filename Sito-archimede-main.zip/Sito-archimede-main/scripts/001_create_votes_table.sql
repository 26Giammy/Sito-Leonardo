-- Create votes table for proposals/news
create table if not exists public.votes (
  id uuid primary key default gen_random_uuid(),
  item_id text not null,
  item_type text not null check (item_type in ('news', 'proposal', 'service')),
  vote_type text not null check (vote_type in ('pro', 'contro')),
  created_at timestamp with time zone default now()
);

-- Enable RLS
alter table public.votes enable row level security;

-- Allow anyone to view votes (public voting system)
create policy "votes_select_all"
  on public.votes for select
  using (true);

-- Allow anyone to insert votes (public voting system)
create policy "votes_insert_all"
  on public.votes for insert
  with check (true);

-- Create index for faster queries
create index if not exists votes_item_id_idx on public.votes(item_id);
create index if not exists votes_item_type_idx on public.votes(item_type);

-- Create a view for vote counts
create or replace view public.vote_counts as
select 
  item_id,
  item_type,
  count(*) filter (where vote_type = 'pro') as pro_count,
  count(*) filter (where vote_type = 'contro') as contro_count
from public.votes
group by item_id, item_type;
