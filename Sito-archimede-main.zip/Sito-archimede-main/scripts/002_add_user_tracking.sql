-- Add user_session column to track individual votes
alter table public.votes add column if not exists user_session text;

-- Create unique constraint to prevent duplicate votes from same session
create unique index if not exists votes_unique_user_item 
  on public.votes(item_id, user_session);

-- Allow users to delete their own votes (for changing vote)
create policy "votes_delete_own"
  on public.votes for delete
  using (true);

-- Update the view to handle the new structure
drop view if exists public.vote_counts;
create or replace view public.vote_counts as
select 
  item_id,
  item_type,
  count(distinct user_session) filter (where vote_type = 'pro') as pro_count,
  count(distinct user_session) filter (where vote_type = 'contro') as contro_count
from public.votes
group by item_id, item_type;
